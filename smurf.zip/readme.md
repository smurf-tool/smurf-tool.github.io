# SMURF
## Installation
You can make use of our provided Docker container by issuing the following two commands:
```bash
docker build -t smurf .
docker run --cap-add=SYS_ADMIN -it smurf:latest /bin/bash 
```

If you want to install it locally you need a working Node and NPM installation depending on your system and additionally need to install our dependencies:
```
npm install
```
## Usage
```bash
node smurf.js --url https://realtor.com
```  

Will visit ```https://realtor.com``` and generate a simplified inclusion tree of the main frame.
It will print those chains which exhibit more than two parties according the the eTLD+1.

Additionally supplying ```--showCspResults``` as a command line parameter will additionally provide the results of our incompatibility analysis of the observed behavior aggregated to hosts.

## Notes
Terminal with color support and a dark background recommended.

This stand-alone version only prints a simplified version of the tree to make it readable on the console.
More on this and about the tree format is displayed after execution.
