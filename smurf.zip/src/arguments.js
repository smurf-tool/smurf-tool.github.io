const ArgumentParser = require('argparse').ArgumentParser;

const parser = new ArgumentParser({
    version: '0.0.1',
    addHelp: true,
    description: 'SMURF prototype using puppeteer'
});

parser.addArgument(
    '--url',
    {
        help: 'Supplies the Url to crawl.',
        required: true
    }
);

parser.addArgument(
    '--showApiResults',
    {
        help: 'Displays the APIs used aggregated to hosts.',
        action: 'storeTrue'
    }
);

parser.addArgument(
    '--showCspResults',
    {
      help: 'Displays the CSP roadblocks associated to the violating hosts.',
      action: 'storeTrue'
    }
);




config = parser.parseArgs();
config.loadTimeout = 30000;
config.afterTimeout = 3000;
config.executablePath = '/usr/bin/chromium-browser';
config.args = ['--disable-dev-shm-usage'];
config.sep = "=========================================================================================================";

module.exports = {
    config
};
